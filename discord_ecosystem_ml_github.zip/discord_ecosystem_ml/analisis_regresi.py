"""
Analisis regresi untuk dataset Discord Ecosystem 2026.
Contoh:
    python analisis_regresi.py --csv discord_ecosystem_2026.csv
"""
import argparse
import os
import sys
import numpy as np
import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor

TARGET = "stars"

# Kolom yang dapat membocorkan target atau berupa identitas/tautan.
EXCLUDE_EXACT = {
    "stars_per_day", "star_per_day", "starsperday",
    "repo_name", "repository_name", "name", "full_name",
    "url", "html_url", "repo_url", "id", "repo_id",
    "description", "readme"
}
EXCLUDE_PARTS = ("stars_per_day", "star_per_day", "target")

def main():
    parser = argparse.ArgumentParser(description="Perbandingan algoritma regresi untuk dataset Discord Ecosystem 2026")
    parser.add_argument("--csv", default="discord_ecosystem_2026.csv", help="Lokasi file CSV")
    parser.add_argument("--xgboost", action="store_true", help="Sertakan XGBoost jika sudah terpasang")
    args = parser.parse_args()

    if not os.path.exists(args.csv):
        print(f"File CSV tidak ditemukan: {args.csv}")
        print("Pastikan file CSV sudah diunduh dan lokasi/nama file pada argumen --csv benar.")
        sys.exit(1)

    df = pd.read_csv(args.csv)
    df.columns = [str(c).strip() for c in df.columns]

    print("=" * 70)
    print("ANALISIS DATASET DISCORD ECOSYSTEM 2026")
    print("=" * 70)
    print(f"Ukuran dataset: {df.shape[0]} baris, {df.shape[1]} kolom")
    print("\nKolom yang tersedia:")
    print(df.columns.tolist())
    print("\nContoh data:")
    print(df.head())

    # Cari target tanpa mengasumsikan kapitalisasi nama kolom.
    col_map = {c.lower().strip(): c for c in df.columns}
    target_col = col_map.get(TARGET)
    if target_col is None:
        print(f"\nERROR: kolom target '{TARGET}' tidak ditemukan.")
        print("Periksa daftar kolom di atas dan ubah TARGET di dalam script jika diperlukan.")
        sys.exit(2)

    # Hilangkan baris yang targetnya kosong dan pastikan target numerik.
    df[target_col] = pd.to_numeric(df[target_col], errors="coerce")
    data = df.dropna(subset=[target_col]).copy()
    data = data[data[target_col] >= 0]

    excluded = set(EXCLUDE_EXACT)
    features = []
    for col in data.columns:
        low = col.lower().strip()
        if col == target_col:
            continue
        if low in excluded or any(part in low for part in EXCLUDE_PARTS):
            continue
        # Hindari kolom teks panjang/identitas yang biasanya tidak informatif.
        if low.endswith("_url") or low.endswith("_id"):
            continue
        if data[col].nunique(dropna=True) <= 1:
            continue
        features.append(col)

    if not features:
        print("Tidak ada fitur yang dapat digunakan setelah penyaringan.")
        sys.exit(3)

    X = data[features].copy()
    y = data[target_col].copy()

    # Hilangkan kolom tanggal mentah agar pipeline tidak gagal; fitur turunan numerik tetap bisa digunakan.
    for col in list(X.columns):
        if pd.api.types.is_datetime64_any_dtype(X[col]):
            X = X.drop(columns=[col])

    # Kolom numerik berbentuk teks yang bisa dikonversi secara konsisten akan dikonversi.
    for col in X.columns:
        if X[col].dtype == "object":
            converted = pd.to_numeric(X[col], errors="coerce")
            if converted.notna().mean() >= 0.85:
                X[col] = converted

    numeric_features = X.select_dtypes(include=[np.number, "bool"]).columns.tolist()
    categorical_features = [c for c in X.columns if c not in numeric_features]

    print("\nTarget:", target_col)
    print("Fitur yang digunakan:", X.columns.tolist())
    print("Fitur numerik:", numeric_features)
    print("Fitur kategori:", categorical_features)
    print(f"Jumlah baris siap pakai: {len(X)}")

    if len(X) < 5:
        print("Dataset terlalu kecil untuk pembagian train/test yang bermakna (minimal disarankan 5 baris).")
        sys.exit(4)

    numeric_pipe = Pipeline([
        ("imputer", SimpleImputer(strategy="median"))
    ])
    categorical_pipe = Pipeline([
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("encoder", OneHotEncoder(handle_unknown="ignore"))
    ])

    transformers = []
    if numeric_features:
        transformers.append(("num", numeric_pipe, numeric_features))
    if categorical_features:
        transformers.append(("cat", categorical_pipe, categorical_features))

    preprocessor = ColumnTransformer(transformers=transformers, remainder="drop")
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    models = {
        "Linear Regression": LinearRegression(),
        "Random Forest Regression": RandomForestRegressor(
            n_estimators=200, random_state=42, n_jobs=-1
        )
    }

    if args.xgboost:
        try:
            from xgboost import XGBRegressor
            models["XGBoost Regression"] = XGBRegressor(
                n_estimators=200,
                max_depth=5,
                learning_rate=0.05,
                objective="reg:squarederror",
                random_state=42,
                n_jobs=-1
            )
        except ImportError:
            print("\nXGBoost belum terpasang. Jalankan: pip install xgboost")

    results = []
    for name, model in models.items():
        pipe = Pipeline([
            ("preprocessor", preprocessor),
            ("model", model)
        ])
        pipe.fit(X_train, y_train)
        predictions = pipe.predict(X_test)
        results.append({
            "Algoritma": name,
            "MAE": mean_absolute_error(y_test, predictions),
            "MSE": mean_squared_error(y_test, predictions),
            "R2": r2_score(y_test, predictions)
        })

    results_df = pd.DataFrame(results).sort_values("MAE")
    print("\nHASIL PERBANDINGAN (data uji)")
    print(results_df.round(4).to_string(index=False))
    results_df.to_csv("hasil_evaluasi_regresi.csv", index=False)
    print("\nHasil disimpan ke: hasil_evaluasi_regresi.csv")
    print("Catatan: MAE/MSE lebih kecil umumnya lebih baik; R2 mendekati 1 umumnya lebih baik.")
    print("Angka hasil harus ditafsirkan sesuai skala stars dan distribusi dataset.")

if __name__ == "__main__":
    main()
