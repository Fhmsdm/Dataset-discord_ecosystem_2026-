# Analisis Machine Learning — Discord Ecosystem 2026

**Pemilik dataset:** Fahmi Saddam  
**Repository dataset:** https://github.com/Fhmsdm/Dataset-discord_ecosystem_2026-

## Deskripsi
Proyek ini membandingkan algoritma regresi untuk memperkirakan jumlah `stars` pada repositori yang berkaitan dengan ekosistem Discord. Model yang dibandingkan:

- Linear Regression
- Random Forest Regression
- XGBoost Regression (opsional)

Evaluasi regresi menggunakan MAE, MSE, dan R². Dataset juga dapat dianalisis dengan klasifikasi tingkat popularitas (rendah, sedang, tinggi).

> **Penting:** Jalankan pemeriksaan kolom terlebih dahulu. Nama kolom pada CSV harus sesuai dengan dataset yang sebenarnya. Program akan menampilkan kolom yang tersedia dan memilih fitur yang cocok secara otomatis. Kolom target yang digunakan adalah `stars`.

## Struktur file
```text
discord_ecosystem_ml/
├── README.md
├── requirements.txt
└── analisis_regresi.py
```

## Cara menjalankan di Google Colab
1. Buka https://colab.research.google.com/
2. Buat notebook baru.
3. Upload file CSV dataset melalui panel **Files** atau gunakan link unduhan CSV mentah dari repository.
4. Jika file sudah di-upload, jalankan:
   ```python
   !pip install -r requirements.txt
   !python analisis_regresi.py --csv /content/discord_ecosystem_2026.csv
   ```
5. Sesuaikan nama file setelah `--csv` jika nama CSV berbeda.

## Cara menjalankan di komputer
1. Download/clone repository dataset.
2. Letakkan file `analisis_regresi.py` dan CSV di folder yang sama, atau masukkan lokasi CSV melalui argumen `--csv`.
3. Install pustaka:
   ```bash
   pip install -r requirements.txt
   ```
4. Jalankan:
   ```bash
   python analisis_regresi.py --csv discord_ecosystem_2026.csv
   ```

## Metode
1. Memeriksa struktur dan kolom dataset.
2. Menggunakan `stars` sebagai target prediksi.
3. Menghapus baris yang targetnya kosong.
4. Memisahkan data menjadi 80% data latih dan 20% data uji.
5. Mengisi nilai fitur yang kosong dan melakukan One-Hot Encoding untuk fitur kategori.
6. Membandingkan model menggunakan data uji yang sama.

## Interpretasi metrik
- **MAE:** rata-rata selisih absolut antara prediksi dan nilai sebenarnya. Lebih kecil lebih baik.
- **MSE:** rata-rata kuadrat kesalahan prediksi. Lebih kecil lebih baik.
- **R²:** mengukur seberapa baik model menjelaskan variasi target. Mendekati 1 umumnya lebih baik; nilai dapat negatif bila model buruk.

Nilai MAE dan MSE **tidak harus di bawah 1** karena bergantung pada skala target. Kesimpulan model terbaik dibuat berdasarkan hasil nyata yang keluar saat program dijalankan, bukan angka contoh.

## Catatan metodologi
- Kolom `stars_per_day` atau kolom lain yang dihitung langsung dari `stars` tidak digunakan sebagai fitur untuk mengurangi risiko **data leakage**.
- Kolom identitas seperti nama repositori, URL, dan ID tidak otomatis dipakai sebagai fitur.
- Jika `stars` tidak ditemukan, program akan berhenti dan menampilkan kolom yang tersedia. Periksa nama kolom target pada CSV.
- Hasil penelitian hanya berlaku pada data dan fitur yang digunakan. Korelasi/prediksi tidak otomatis membuktikan hubungan sebab-akibat.

## Referensi
1. Dataset: [Dataset Discord Ecosystem 2026 — GitHub](https://github.com/Fhmsdm/Dataset-discord_ecosystem_2026-)
2. Scikit-learn — Regression metrics: https://scikit-learn.org/stable/modules/model_evaluation.html
3. Scikit-learn — Linear models: https://scikit-learn.org/stable/modules/linear_model.html
4. Scikit-learn — Random Forest: https://scikit-learn.org/stable/modules/ensemble.html#forest
5. XGBoost documentation: https://xgboost.readthedocs.io/

## Penulis
Fahmi Saddam
